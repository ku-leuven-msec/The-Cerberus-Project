#!/bin/bash
set -e

export base_base=`pwd`
export base=$base_base/stuff_build

rm -rf $base
mkdir $base
cd $base
$base_base/scripts/get_llvm_src_tree.sh
$base_base/scripts/install-shadowstack-files.sh


mkdir -p $base/debug-build
mkdir -p $base/release-build

cd $base/debug-build
$base_base/scripts/cmake_debug.sh

cd $base/release-build
$base_base/scripts/cmake_release.sh

#cd $base/musl
#CC=$base/debug-install/bin/clang ./configure --enable-debug --disable-shared --prefix=$base/debug-install
