//#define COUNT_FUNCTION_CALLS     //Ignore this one

//-- Shadow stack mechanism (choose 1)
//--- Compact shadow stack
#define SHADOW_STACK_COMPACT_REGISTER
//#define SHADOW_STACK_COMPACT_GLOBAL
//#define SHADOW_STACK_COMPACT_SEGMENT
//--- Parallel shadow stack
//#define SHADOW_STACK_PARR_CONSTANT_OFFSET
//#define SHADOW_STACK_PARR_REGISTER

//-- Shadow stack integrity protection (choose 1)
// #define SHADOW_STACK_MPK
// #define SHADOW_STACK_MPX
#define SHADOW_STACK_ERIM
