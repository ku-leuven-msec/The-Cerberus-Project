/*
 * libtem_signals.h
 */

#ifndef __LIBTEM_SIGNALS_H_
#define __LIBTEM_SIGNALS_H_

#ifdef __cplusplus
extern "C"
{
#endif

int libtem_reg_signals();

#ifdef __cplusplus
}
#endif
  
#endif // __LIBTEM_SIGNALS_H_
