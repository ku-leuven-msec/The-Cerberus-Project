#ifndef _TEST_SECRETSO_H_
#define _TEST_SECRETSO_H_

extern void set_var(unsigned long * var);
extern unsigned long read_var(unsigned long * var, unsigned long add);

#endif // _TEST_SECRETSO_H_
